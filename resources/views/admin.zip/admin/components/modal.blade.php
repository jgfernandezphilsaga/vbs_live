<div class="modal fade" id="confirmationModal" data-bs-target="confirmationModal" data-bs-backdrop="static" tabindex="-1" aria-labelledby="ConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5>Confirm?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p style="font-size: 16px">
                    Are you sure you want to post this request?</p><br><p> Any details cannot be changed once posted.
                </p>
            </div>
            <div class="modal-footer">
                <button id="modal-post-btn" class="btn btn-post" type="button" onclick="postRequest()">Post</button>
                <button class="btn btn-danger" type="button" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal modal-xl fade" id="requestDetailModal" data-request-id="" tabindex="-1" aria-labelledby="detailModelLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">   
                <div class="d-flex flex-row" style="text-align:end; align-items:center">
                    <h1 class="modal-title fs-5 flex-grow-1 w-100" id="detailModelLabel">Request Details</h1>
                    <span id="status-span" style="margin:0px 10px; padding: 10px 8px; position: relative; display: inline-block; border-radius: 5px;">STATUS</span>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="p-dev" id="printable-div">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="d-flex flex-row">
                                <div class="flex-grow-1 text-center">
                                    <div class="d-flex flex-row align-items-center justify-content-evenly">
                                        <img class="modal-left-title-image" src="{{ asset('assets/images/logo/pmc-logo.png') }}" alt="PMC logo">
                                        <img class="modal-left-title-image" src="{{ asset('assets/images/logo/mmprc-logo.png') }}" alt="MMPRC logo">
                                    </div>
                                </div>
                                <div class="flex-grow-1 flex-shrink-0">
                                    <div class="d-flex flex-column align-items-center">
                                        <h4 class="view-details-headers">Philsaga Mining Corporation</h4>
                                        <div class="mt-2">
                                            <p class="mt-1 mb-0 view-details-headers" >Material Control Department</p>
                                            <p class="m-0 view-details-headers" >MCD-Form-0 Rev.1</p>
                                            <p class="m-0 view-details-headers" >Effectivity Date: Sept. 01, 2023</p>
                                        </div>
                                        <h5 class="my-3 view-details-headers" style="font-weight:bold;">VEHICLE REQUISITION SLIP</h5>
                                    </div>
                                </div>
                                <div class="flex-grow-1 text-center">
                                    <div class="d-flex flex-row align-items-center justify-content-evenly">
                                        <img class="modal-right-title-image" src="{{ asset('assets/images/logo/pmc-values.png') }}" alt="PMC values">
                                        <img class="modal-right-title-image" src="{{ asset('assets/images/logo/iso-cert.png') }}" alt="PMC ISO cert">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-1">
                        <div class="col-md-6 d-flex flex-column" style="text-align:start">
                            <div class="col-md-6 d-flex flex-column justify-content-center">
                                <div class="d-flex flex-row">
                                    <p class=" m-0" >Reference ID: </p>
                                    <div class="placeholder-glow mx-2 flex-grow-1">
                                        <span class="w-100" id="reference-id"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 d-flex flex-column justify-content-center">
                                <div class="d-flex flex-row">
                                    <p class=" m-0" >Requesting Dept.: </p>
                                    <div class="placeholder-glow mx-2 flex-grow-1">
                                        <span class="w-100" id="requesting-dept"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 d-flex flex-column" style="text-align:end">
                            <div class="d-flex flex-row" style="text-align:end">
                                <p class="m-0 flex-grow-1">Date: </p>
                                <div class="placeholder-glow mx-2">
                                    <span class="" id="header-date" style="width: 15em"></span>
                                </div>
                            </div>
                            <div class="d-flex flex-row">
                                <p class="m-0 flex-grow-1" >Requested Vehicle: </p>
                                <div class="placeholder-glow mx-2">
                                    <span class="" id="requested-vehicle" style="width: 15em"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-bordered mb-1">
                                <thead>
                                    <th style="vertical-align:middle; text-align:center; width: 10%">Date</th>
                                    <th style="vertical-align:middle; text-align:center; width: 10%">Time of Departure</th>
                                    <th style="vertical-align:middle; text-align:center; width: 10%">Requested Hour(s)</th>
                                    <th style="text-align:center; width: 40%; padding: 0px" colspan="2">
                                        <div class="d-flex flex-column">
                                            <p style="vertical-align:top; border-bottom:solid; border-bottom-width: 1px; border-color: rgb(222, 226, 230)">Destination</p>
                                            <div class="d-flex flex-row">
                                                <p class="col-6">From</p>
                                                <p class="col-6" style="border-left:solid; border-left-width: 0px; border-color: rgb(222, 226, 230)">To</p>
                                            </div>
                                        </div>
                                    </th>
                                    <th style="text-align:center; width: 10%">Trip Type</th>
                                    <th style="text-align:center; width: 20%">Name of Passenger(s)</th>
                                </thead>
                                <tbody id="modal-tbody">
                                    <!-- @for($i = 0; $i < 6; $i++)
                                        <tr id="row-{{ $i }}">        
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                                    <span class="placeholder w-100" id="date-{{ $i }}"></span>
                                                </div>
                                            </td>
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                                    <span class="placeholder w-100" id="departure-{{ $i }}"></span>
                                                </div>
                                            </td> 
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                                    <span class="placeholder w-100" id="hours-{{ $i }}"></span>
                                                </div>
                                            </td>  
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                                                    <span class="placeholder w-100" id="destination-from-{{ $i }}"></span>
                                                </div>
                                            </td>    
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                                                    <span class="placeholder w-100" id="destination-to-{{ $i }}"></span>
                                                </div>
                                            </td> 
                                            <td class="p-1">
                                                <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                                    <span class="placeholder w-100" id="passengers-{{ $i }}"></span>
                                                </div>
                                            </td>
                                        </tr>
                                    @endfor -->
                                </tbody>
                            </table>
                            <p style="font-size: 0.7rem;">Note: Submit the requisition (2) two days before the scheduled day trup and must notify (1) one day before to requesting department if approve or reject.</p>
                            <div class="d-flex flex-row my-3">
                                <p class="mb-0">Purpose: </p>
                                <div class="placeholder-glow mx-2 flex-grow-1 purpose-content" id="purpose-content">
                                    <span class="w-100 purpose" id="purpose"></span>
                                    <span class="read-more" id="togglePurpose">Read more</span>
                                </div>
                            </div>
                            <hr>
                            <div class="col-md-12 d-flex flex-row">
                                <div class="col-md-4 d-flex flex-column px-3">
                                    <p class="mb-0">Requested By:</p>
                                    <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                        <span class="w-100" id="requested-by"></span>
                                    </div>
                                    <hr class="m-0">
                                    <p style="text-align: center">Name/Signature</p>
                                </div>
                                <div class="col-md-4 d-flex flex-column px-3">
                                    <p class="mb-0">Approved By:</p>
                                    <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                        <span class="w-100" id="approved-by"></span>
                                    </div>
                                    <hr class="m-0">
                                    <p style="text-align: center">Requesting Dept. Manager</p>
                                </div>
                                <div class="col-md-4 d-flex flex-column px-3">
                                    <p class="mb-0">Acknowledged By:</p>
                                    <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                        <span class="w-100" id="acknowledged-by"></span>
                                    </div>
                                    <hr class="m-0">
                                    <p style="text-align: center">Dispatcher/Dept. Manager</p>
                                </div>
                            </div>
                            <div id="remarks-section">
                                <!-- <hr class="my-4" style="border: none; height: 2px; color: black; background-color: black;">
                                <div class="d-flex flex-column my-3">
                                    <p class="mb-0" style="font-weight: bold">Remarks: </p>
                                    <div class="d-flex flex-row flex-wrap" id="remarks" data-remarks-id="1">
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer" id="modal-footer">
                <!-- Buttons are set in the javascript -->
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#requestDetailModal').on('show.bs.modal', function(event) {
            resetModal();

            var button = $(event.relatedTarget);
            var id = button.data('request-id');

            $('#requestDetailModal').data('request-id', id);

            // Initialize header for ajax
            $.ajaxSetup({ 
                headers: { 
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
                } 
            });
        
            $.ajax({
                url: '/request/show/' + id,
                method: 'GET',
                success: function(response) {
                    
                    let row_count = 6;
                    let header_values = response.header;
                    let detail_values = response.detail[0];
                    let remarks_values = response.remarks;

                    let requestor = header_values['user_fullname'];
                    let dept_approver = header_values['dept_approver_fullname'];
                    let gsd_dispatcher = header_values['gsd_manager_fullname'];

                    var status = detail_values['status'];
                    var $statusSpan = $('#status-span');
                    var statusClass;

                    switch (status) {
                        case 'DRAFT':
                            statusClass = 'badge status-saved';

                            if ("{{ session('user_role') === 'dept_secretary'}}") {
                                var questionText = header_values['is_resubmitted'] ? 'Save and resubmit this request for approval?' : 'Post this request for approval?';
                                var buttonText = header_values['is_resubmitted'] ? 'Resubmit' : 'Post';

                                $('#modal-footer').append(
                                    `
                                        <b style="font-size: 0.75vw">${questionText}</b>
                                        <button type="button" class="btn btn-post" onclick="showConfirmationModal()">${buttonText}</button>
                                    `
                                );

                                // $('#modal-footer').append(
                                //     `
                                //         <b style="font-size: 0.75vw">${questionText}</b>
                                //         <button type="button" class="btn btn-post" onclick="postRequest()">${buttonText}</button>
                                //     `
                                // );
                            } 
  
                                $('#modal-footer').append(
                                    `
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    `
                                );
                            break;
                        case 'POSTED':
                            statusClass = 'badge status-posted';

                            // if ("{{ session('user_role') === 'gsd_manager'}}") {
                            //     $('#modal-footer').append(
                            //         // NEED TO UPDATE (ADD RESTRICTION WHERE CAN ONLY BE UPDATED IS THE GSD MANAGER APPROVED ALREADY)
                            //         `
                            //             <div>
                            //                 <b style="font-size: 0.75vw">Complete this request?</b>
                            //                 <button type="button" class="btn btn-approve" onclick="completeRequest()">Complete</button>
                            //                 <button type="button" class="btn btn-hold" onclick="holdRequest()">Hold</button>
                            //                 <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                            //             </div>
                            //         `

                            //         // <button type="button" class="btn btn-danger" onclick="holdRequest()">Hold</button>
                            //     );

                            //     break;
                            // } else {
                                $('#modal-footer').append(
                                    `
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    `
                                );
                                
                                break;
                            // }
                        case 'APPROVED':
                            statusClass = 'badge status-approved';

                            if ("{{ session('user_role') === 'gsd_manager'}}") {
                                $('#modal-footer').append(
                                    // NEED TO UPDATE (ADD RESTRICTION WHERE CAN ONLY BE UPDATED IS THE GSD MANAGER APPROVED ALREADY)
                                    `
                                        <div>
                                            <b style="font-size: 0.75vw">Complete this request?</b>
                                            <button type="button" class="btn btn-approve" onclick="completeRequest()">Complete</button>
                                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    `
                                );

                                break;
                            } else {
                                $('#modal-footer').append(
                                    `
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    `
                                );
                                
                                break;
                            }

                            break;
                        case 'HOLD':
                            statusClass = 'badge status-hold';
                            
                            if ("{{ session('user_role') === 'dept_secretary'}}") {
                                $('#modal-footer').append(
                                    `
                                        <b style="font-size: 0.75vw">Repost this request?</b>
                                        <button type="button" class="btn btn-post" onclick="showConfirmationModal()">Post</button>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    `
                                );
                                
                                break;
                            } else {
                                $('#modal-footer').append(
                                    `
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                    `
                                );

                                break;
                            }
                        case 'COMPLETED':
                            statusClass = 'badge status-completed';

                            $('#modal-footer').append(
                                `
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                `
                            );

                            break;
                            case 'CANCEL':
                            statusClass = 'badge status-cancel';

                            $('#modal-footer').append(
                                `
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                `
                            );

                            break;
                        default:
                            statusClass = ' badge bg-secondary';
                    }
                    $statusSpan.addClass(statusClass);
                    $statusSpan.text(status);
                    
                    $("#reference-id").removeClass("placeholder");
                    $("#requesting-dept").removeClass("placeholder");
                    $("#header-date").removeClass("placeholder");
                    $("#requested-vehicle").removeClass("placeholder");
                    $("#purpose").removeClass("placeholder");
                    $("#requested-by").removeClass("placeholder");
                    $("#approved-by").removeClass("placeholder");
                    $("#acknowledged-by").removeClass("placeholder");

                    $("#reference-id").text(header_values['reference_id']);
                    $("#requesting-dept").text(detail_values['department']);
                    $("#header-date").text(formatDate(detail_values['created_at'], 'header'));
                    $("#requested-vehicle").text(detail_values['vehicle']);
                    
                    $("#purpose").text(detail_values['purpose']); 
                    if(!hasExceededLineClamp($('#purpose'))) { $('#togglePurpose').hide(); }

                    $("#requested-by").text(requestor); 
                    $("#approved-by").text(dept_approver); 
                    $("#acknowledged-by").text(gsd_dispatcher); 

                    // $('#footer-action').innerHTML();

                    // Add more rows if details exceed default amount
                    if(response.detail.length > 6) {
                        let excessRowsCount = response.detail.length - 5; // 5 is the max number of rows
                        let rowIndex =  response.detail.length - 1; // Set index for rows to be added 

                        for(excessRowsCount; excessRowsCount > 0; excessRowsCount--) {
                            var newRow = `
                                <tr id="row-${rowIndex}">        
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                            <span class="placeholder w-100" id="date-${rowIndex}"></span>
                                        </div>
                                    </td>
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                            <span class="placeholder w-100" id="departure-${rowIndex}"></span>
                                        </div>
                                    </td> 
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                            <span class="placeholder w-100" id="hours-${rowIndex}"></span>
                                        </div>
                                    </td>  
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                                            <span class="placeholder w-100" id="destination-from-${rowIndex}"></span>
                                        </div>
                                    </td>    
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                                            <span class="placeholder w-100" id="destination-to-${rowIndex}"></span>
                                        </div>
                                    </td> 
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                            <span class="placeholder w-100" id="trip-type-${rowIndex}"></span>
                                        </div>
                                    </td>
                                    <td class="p-1">
                                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                                            <span class="placeholder w-100" id="passengers-${rowIndex}"></span>
                                        </div>
                                    </td>
                                </tr>
                            `;

                            // Append row to table body
                            $('#modal-tbody').append(newRow);
                            rowIndex++;
                        } 
                    }

                    let loopCount = 0;
                    for (let index = 0; index < response.detail.length; index++) {
                        let values = response.detail[index];
                        // console.log(values);
                        let passengersArray = values['passengers'].split("/");
                        let passengers = ""; 
                        passengersArray.forEach(function (currentValue, index, array){
                            let tempPassenger = currentValue.split("|"); // Separate ID with FullName, from 'PMC-XXXXX | Doe, John' to ['PMC-XXXXX']['Doe, John']
                            passengers += tempPassenger[1]; // Index '1' to get the name of the passenger since '0' is the ID
                        
                            if (index !== array.length - 1) {
                                passengers += "<br>";
                            }
                        });

                        $(`#date-${index}`).removeClass("placeholder");
                        $(`#departure-${index}`).removeClass("placeholder");
                        $(`#hours-${index}`).removeClass("placeholder");
                        $(`#destination-from-${index}`).removeClass("placeholder");
                        $(`#destination-to-${index}`).removeClass("placeholder");
                        $(`#trip-type-${index}`).removeClass("placeholder");
                        $(`#passengers-${index}`).removeClass("placeholder");

                        $(`#date-${index}`).text(formatDate(values['departure_time'], 'detail'));
                        $(`#departure-${index}`).text(formatTime(values['departure_time']));
                        $(`#hours-${index}`).text(values['requested_hrs']);
                        $(`#destination-from-${index}`).text(values['destination_from']);
                        $(`#destination-to-${index}`).text(values['destination_to']);
                        $(`#trip-type-${index}`).text(values['trip_type']);
                        $(`#passengers-${index}`).html(passengers);
                        // $(`#passengers-${index}`).text(values['passengers']);

                        loopCount++;
                    }

                    if(loopCount < row_count) {
                        for(loopCount; loopCount < row_count; loopCount++) {
                            $(`#date-${loopCount}`).removeClass("placeholder");
                            $(`#departure-${loopCount}`).removeClass("placeholder");
                            $(`#hours-${loopCount}`).removeClass("placeholder");
                            $(`#destination-from-${loopCount}`).removeClass("placeholder");
                            $(`#destination-to-${loopCount}`).removeClass("placeholder");
                            $(`#trip-type-${loopCount}`).removeClass("placeholder");
                            $(`#passengers-${loopCount}`).removeClass("placeholder");

                            $(`#date-${loopCount}`).html('&nbsp;');
                            $(`#departure-${loopCount}`).html('&nbsp;'); 
                            $(`#hours-${loopCount}`).html('&nbsp;');
                            $(`#destination-from-${loopCount}`).html('&nbsp;');
                            $(`#destination-to-${loopCount}`).html('&nbsp;');
                            $(`#trip-type-${loopCount}`).html('&nbsp;');
                            $(`#passengers-${loopCount}`).html('&nbsp;'); 

                        }
                    }

                    if(remarks_values.length > 0) {
                        $('#remarks-section').append(`
                            <hr class="my-4" style="border: none; height: 2px; color: black; background-color: black;">
                            <div class="d-flex flex-column my-3">
                                <p class="mb-0" style="font-weight: bold">Remarks: </p>
                                <div class="d-flex flex-row overflow-x-auto remarks-scrollbar" id="remarks">
                                </div>
                            </div>
                        `);

                        let remarksLoopCount = 0;
                        for(let index = 0; index < remarks_values.length; index++) {
                            let remark_data = remarks_values[index];

                            let remark_status_class = '';
                            let remark_status = '';
                            switch(remark_data['status']) {
                                case 'SAVED':
                                    remark_status_class = 'status-saved';
                                    remark_status = 'SAVED';
                                    break;
                                case 'POSTED':
                                    remark_status_class = 'status-posted';
                                    remark_status = 'POSTED';
                                    break;
                                case 'PARTIALLY APPROVED':
                                    remark_status_class = 'status-completed';
                                    remark_status = 'PARTIALLY APPROVED';
                                    break;
                                case 'FULLY APPROVED':
                                    remark_status_class = 'status-approved';
                                    remark_status = 'APPROVED';
                                    break;
                                case 'HOLD':
                                    remark_status_class = 'status-hold';
                                    remark_status = 'HOLD';
                                    break;
                                case 'CANCEL':
                                    remark_status_class = 'status-cancel';
                                    remark_status = 'CANCEL';
                                    break;
                                default:
                                    break;
                            }

                            //  top: -13px; right: 5%
                            var newRemark = `
                                <div class="col-4 p-1">
                                    <div class="card p-2 d-flex flex-column justify-content-between" style="min-height: 76px">
                                        <div>
                                            <div class="d-flex flex-row justify-content-between">
                                                <p>${remark_data['remarks']}</p>
                                                <div class="status-span p-1 ${remark_status_class}" id="remark-status-span" style="position: relative; display: inline-block; border-radius: 5px;">
                                                    <p style="color: white">${remark_status}</p>
                                                </div>
                                            </div>
                                            <div class="d-flex flex-row mt-1 justify-content-between align-items-end" style="font-style: italic; font-size: 10px;">
                                                <p>
                                                    ${remark_data['sender_name']}<br>
                                                    ${remark_data['sender_position']}
                                                </p>
                                                <p>${formatDate(remark_data['created_at'], 'header')} ${formatTime(remark_data['created_at'])}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                            
                            $('#remarks').append(newRemark);
                        }
                    }
                },
                error: function(data) {
                    alert('Error! Login expired. Please login again');

                    location.reload();
                }
            });
        });

        $('#confirmationModal').on('hidden.bs.modal', function () {
            $('.modal-backdrop').css('z-index', 1049); // Set backdrop behind requestDetailModal
            $('.modal-backdrop').show(); // Show backdrop after confirmationModal closes
        });

        $('#togglePurpose').on('click', function() {
            var purposeSpan = $('#purpose');
            if (purposeSpan.hasClass('expanded')) {
                purposeSpan.removeClass('expanded');
                $(this).text('Read more');
            } else {
                purposeSpan.addClass('expanded');
                $(this).text('Read less');
            }
        });

    });

    // Save the vehicle request
    // function saveRequest() {
    //     if(confirm("Are you sure you want to send this request for approval? Any details cannot be changed once sent.")) {
    //         var id = $('#requestDetailModal').data('request-id');
    
    //         updateRequest(id, 2); // 1 = SAVED
    //     }
    // }

    function showConfirmationModal() {
        $('#requestDetailModal').css('z-index', 1050);
        $('#confirmationModal').css('z-index', 1051);

        $('#confirmationModal').modal('show');
    }

    // Post the vehicle request
    function postRequest() {
        $('#modal-post-btn').append('<div class="spinner-border" style="height: 1rem; width: 1rem; margin-left: 5px" role="status"><span class="visually-hidden">Loading...</span></div>');
        $('#modal-post-btn').prop('disabled', true);
        var id = $('#requestDetailModal').data('request-id');
        updateRequest(id, 2); // 2 = POSTED

        // if(confirm("Are you sure you want to post this request? Any details cannot be changed once posted.")) { 
        // }
    }
    // Approve the vehicle request
    function completeRequest() {
        var id = $('#requestDetailModal').data('request-id');
        updateRequest(id, 4); // 4 = APPROVED
        
        // if(confirm("Are you sure you want to approve this request? Any details cannot be changed once approved")) {
        // }
    }

    // Hold the vehicle request
    function holdRequest() {
        var id = $('#requestDetailModal').data('request-id');
        updateRequest(id, 5); // 1 = REVERT STATUS TO 1
        
        // if(confirm("Are you sure you want to hold this request?")) { // removed text: 'Request will require posting from GSD Dispatcher again' 
        // }
    }

    function updateRequest(id, status) {
        $.ajaxSetup({ 
            headers: { 
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
            } 
        });
        
        $.ajax({
            url: '/request/update-status',
            method: 'POST',
            data: {
                id: id, 
                status: status,
            },
            success: function(response) {
                // alert('success: ' + response);
                // console.log(response);

                location.reload();
            },
            error: function(xhr) {
                let errorMessage = xhr.status === 422 ? JSON.parse(xhr.responseText).message : `Error: ${xhr.status} ${xhr.statusText}`;
                // alert('error');

                location.reload();
            }
        });
    }

    function formatDate(isoString, type) {
        // Parse the ISO date string
        const date = new Date(isoString);

        var splitDate;
        switch (type) {
            case 'header':
                splitDate = isoString.split('T');
                break;
            case 'detail':
                splitDate = isoString.split(' ');
                break;
            default:
        }
        
        formatter = splitDate[0];

        // Format the date
        return formatter;
    }

    function formatTime(isoString) {
        // Parse the ISO date string
        const date = new Date(isoString);

        // Create a formatter for the desired time format
        const options = { hour: 'numeric', minute: 'numeric', hour12: true };
        const formatter = new Intl.DateTimeFormat('en-US', options);

        // Format the time
        return formatter.format(date);
    }

    function hasExceededLineClamp($element) {
        if (!$element.length) return false;

        // Get the computed style for -webkit-line-clamp
        var style = getComputedStyle($element[0]);
        var lineClamp = parseInt(style.getPropertyValue('-webkit-line-clamp'));

        if (isNaN(lineClamp) || lineClamp <= 0) return false;

        // Calculate the height of one line
        var lineHeight = parseInt(style.getPropertyValue('line-height'));
        if (isNaN(lineHeight) || lineHeight <= 0) return false;

        // Calculate the expected height based on the number of clamped lines
        var expectedHeight = lineClamp * lineHeight;

        // Compare the expected height to the actual height of the content
        var actualHeight = $element[0].scrollHeight;

        return actualHeight > expectedHeight;
    }

    // Truncate purpose 
    function truncatePurpose(source, size) {
        return source.length > size ? source.slice(0, size - 1) + "…" : source;
    }


    // Reset the modal upon opening
    function resetModal() {
        const $modalTbody = $('#modal-tbody');
        $modalTbody.empty();

        $('#requestDetailModal').data('request-id', '');

        var $statusSpan = $('#status-span');

        // $statusSpan.removeClass(function(index, className) {
        //     return (className.match(/(^|\s)bg-\S+/g) || []).join(' ');
        // });

        $statusSpan.removeClass();

        $statusSpan.text('STATUS');

        $('#reference-id').addClass('placeholder');
        $('#requesting-dept').addClass('placeholder');
        $('#header-date').addClass('placeholder');
        $('#requested-vehicle').addClass('placeholder');
        $('#purpose').addClass('placeholder');
        $('#togglePurpose').show();
        $('#requested-by').addClass('placeholder');
        $('#approved-by').addClass('placeholder');
        $('#acknowledged-by').addClass('placeholder');

        for(index = 0; index < 5; index++) {
            var row = `
                <tr id="row-${index}">        
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                            <span class="placeholder w-100" id="date-${index}"></span>
                        </div>
                    </td>
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                            <span class="placeholder w-100" id="departure-${index}"></span>
                        </div>
                    </td> 
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                            <span class="placeholder w-100" id="hours-${index}"></span>
                        </div>
                    </td>  
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                            <span class="placeholder w-100" id="destination-from-${index}"></span>
                        </div>
                    </td>    
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1 flex-shrink-0" style="text-align:center">
                            <span class="placeholder w-100" id="destination-to-${index}"></span>
                        </div>
                    </td> 
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                            <span class="placeholder w-100" id="trip-type-${index}"></span>
                        </div>
                    </td>
                    <td class="p-1">
                        <div class="placeholder-glow mx-2 flex-grow-1" style="text-align:center">
                            <span class="placeholder w-100" id="passengers-${index}"></span>
                        </div>
                    </td>
                </tr>
            `;

            $('#modal-tbody').append(row);
        }
        
        $('#remarks-section').children().remove();

        $('#modal-footer').empty();
    }
</script>