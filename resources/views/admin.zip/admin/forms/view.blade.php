@extends('layouts.app')

@section('content')
    <div class="col-md-12">
        <div class="header-card">
            <div class="col-md-12">
                <h3 class="page-title">Request Details</h3>
            </div>
        </div>
    </div>
@endsection