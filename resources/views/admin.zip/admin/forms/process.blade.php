@extends('layouts.app')

@section('styles')
    <link href="{{ asset('vbs/pulic/css/forms/forms.css') }}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
@endsection

@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                
                <form id="request-form" action="{{ route('save.request')}}" method="POST">
                    @csrf
                    <div class="card-body">
                        <div class="row" style="text-align:center">
                            <h5>Add Vehicle / Driver</h1>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-8 mb-2">
                                <div class="form-group">
                                    <div class="form-label">Purpose: </div>
                                    {{ $header->purpose }}
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                <div class="form-label">Vehicle Type: </div>
                                    
                                            {{ $header->requested_vehicle}}
                                    
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table" style="display:block; overflow-x:auto;">
                                    <thead>
                                        <th style="width: 5%;">Time of Departure</th>
                                        <th style="width: 10%;">Requested Hrs</th>
                                        <th style="width: 10%;">Starting Location</th>
                                        <th style="width: 10%;">Destination</th>
                                        <th style="width: 10%;">Trip Type</th>
                                        <th style="width: 15%;">Name of Passenger(s)</th>
                                        <th style="width: 1%;"></th>
                                    </thead>
                                    <tbody style="width: 100%;" id="table-body">
                                        @if(Session::get('row_count'))
                                            <?php 
                                                // dd($details[0]);
                                            ?>
                                        @endif
                                        @for($i = 0; $i < count($details); $i++)
                                            <tr class="data-row" data-row-id="{{ $i }}">
                                                <input type="hidden" name="header_id[]" value="{{ $details[$i]->id}}"/>
                                                    <td>
                                                    {{ $details[$i]->departure_time }}
                                                </td>
                                                <td>
                                                    {{ $details[$i]->requested_hrs }}
                                                </td>
                                                <td>
                                                   {{ $details[$i]->destination_from }}
                                                </td>
                                                <td>
                                                    {{ $details[$i]->destination_to }}
                                                </td>
                                                <td>
                                                     {{ $details[$i]->trip_type }}
                                                        
                                                    </select>    
                                                </td>
                                                <td>
                                                    
                                                    {{ $details[$i]->passengers }}
                                                </td>
                                                <td>
                                                    
                                                </td>
                                            </tr>
                                        @endfor
                                        
                                    </tbody>
                                </table>
                            </div>    
                            <div class="col-md-12">
                                <table class="table" style="display:block; overflow-x:auto;">
                                    <thead>
                                        <th style="width: 5%;">Driver Name</th>
                                        <th style="width: 10%;">Vehicle</th>
                                    </thead>
                                    <tbody style="width: 100%;" id="table-body">
                                            <tr class="data-row">
                                               
                                                <td>
                                                    <select class="form-control"  id="driver_details" name="driver_details"  style="width: 100%"></select>
                                                </td>
                                                <td>
                                                  <select class="form-control"  id="vehicle_unit" name="vehicle_unit"  style="width: 100%"></select>
                                                </td>
                                            </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <p style="font-size: 0.7rem;">Note: Submit the requisition (2) two days before the scheduled day trup and must notify (1) one day before to requesting department if approve or reject.</p>
                        <div style="display:flex; flex-direction:row; justify-content:end;">
                        <button class="btn btn-primary me-2 d-flex flex-row align-items-center" id="update-btn" type="button">
                            <i class="fa-solid fa-paper-plane"></i> 
                            &nbsp;
                            <p id="submit-btn-text">Submit</p>
                        </button>
                            <button class="btn btn-danger" type="button" onclick="returnToDash()"><!--onclick="history.back()"-->
                                <i class="fa-solid fa-circle-xmark"></i> Cancel
                            </button>
                        </div>
                    </div>
                      
                </form>
            </div>
        </div>
    </div>

    <script>
    
        
        
        // let count = 2; // For rowId
        let rowCount = $('#table-body').find('tr').length - 1;
        document.addEventListener('DOMContentLoaded', (event) => {
            const reqForm = document.getElementById('request-form');
            const addBtn = document.getElementById('add-btn');
            const updateBtn = document.getElementById('update-btn');
            const tableBody = $('#table-body');
            // const removeBtn = dosucment.getElementById('remove-btn');

 

            updateBtn.addEventListener('click', function(event){
                $('#submit-btn').prop('disabled', true);
                $('#submit-btn-text').text('Updating...');

                
                // Serialize the form
                let requestData = new FormData($('#request-form').get(0));
            
                // AJAX POST request setup
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') 
                    }
                });
                $.ajax({
                    url: '/request/save_process',
                    method : 'POST',
                    data: requestData,
                    processData: false,
                    contentType: false,
                    success: function(response){
                        const protocol = window.location.protocol;
                        const hostname = window.location.hostname;
                        const port = (window.location.port && window.location.port !== undefined) ? `${window.location.port}` : '';

                        if(response.status != 'error') {
                             //console.log(response);
                            //console.log('response.data');
                            window.location.href = `${protocol}//${hostname}:${port}`; // Dashboard
                            triggerToast(response.status, response.message);
                        } else {
                             //console.log('error');
                             //console.log('error at: ' + response.validation + '|' + response.input + '|' + response.row);                        
                            let errorMessage = response.input.length == 1 ? response.message : 'Multiple errors found. Errors are highlighted in the form.'; 
                            //console.log(response.input + '|' + response.input.length);
                            triggerToast(response.status, errorMessage);
                        }      
                    },
                    error: function(data) {
                        // console.log('ajax error');
                        // console.log(data);
                        triggerToast('error', data.responseText);
                    }
                });

                $('#submit-btn').prop('disabled', false);
                $('#submit-btn-text').text('Save');
            });
        });

        

    function setSelect2Inputs () {
    const protocol = window.location.protocol;
    const hostname = window.location.hostname;
    const port = window.location.port ? `:${window.location.port}` : '';

    $('.emp-select2').select2({
        allowClear: true,
        minimumInputLength: 2,
        ajax: {
            url: `${protocol}//${hostname}${port}/api/hris-api.php`,
            delay: 2000,
            dataType: 'json',
            data: (params) => ({
                emp: params.term
            }),
            processResults: (data) => {
                const results = data.map(emp => ({
                    id: `${emp.EmpID}|${emp.FullName}`,
                    text: emp.FullName
                }));
                return { results };
            }
        }
    });

}

$('#vehicle_unit').select2({
    ajax: {
        url: '/api/vehicle_api.php',
        dataType: 'json',
        delay: 250,
        data: (params) => ({
            vehicle: params.term
        }),
        processResults: (data) => {
            //console.log('API response:', data);

            if (!Array.isArray(data)) {
                console.warn('Expected an array but got:', data);
                return { results: [] };
            }

            const results = data.map(vehicle => ({
                id: `${vehicle.PLATE_NO}`,
                text: `${vehicle.MODEL} - ${vehicle.PLATE_NO}`
            }));

            return { results };
        },
        error: function (xhr, status, error) {
            console.error('Select2 AJAX error:', {
                status: status,
                error: error,
                responseText: xhr.responseText
            });
            alert('Error loading vehicle data. Check console for details.');
        },
        cache: true
    },
    placeholder: 'Search for Model / Plate No.',
    minimumInputLength: 4
});

$('#driver_details').select2({
    ajax: {
        url: '/api/vehicle_api.php',
        dataType: 'json',
        delay: 250,
        data: (params) => ({
            driver_details: params.term
        }),
        processResults: (data) => {
            console.log('API response:', data);

            if (!Array.isArray(data)) {
                console.warn('Expected an array but got:', data);
                return { results: [] };
            }

            const results = data.map(driver_details => ({
                id: `${driver_details.employee_id}`,
                text: `${driver_details.last_name} - ${driver_details.first_name}- ${driver_details.employee_id}`
            }));

            return { results };
        },
        error: function (xhr, status, error) {
            console.error('Select2 AJAX error:', {
                status: status,
                error: error,
                responseText: xhr.responseText
            });
            alert('Error loading driver data. Check console for details.');
        },
        cache: true
    },
    placeholder: 'Search for driver Last Name / Employee ID.',
    minimumInputLength: 4
});

        function returnToDash() {
            const protocol = window.location.protocol;
            const hostname = window.location.hostname;
            const port = window.location.port ? `:${window.location.port}` : '';
            window.location.href = `${protocol}//${hostname}${port}`;
        }

</script>

@endsection
