@section('content')
    <div>

    </div>
    <script>

    </script>
@endsection