import BootstrapTable from './BootstrapTable.vue'

export default BootstrapTable
