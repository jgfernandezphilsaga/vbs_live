## List of donators

* Richard C Jordan - $35
* Janet Moery - $5
* Halskov Rene - $10.00
* Arambula Garcia Angel - $5.00
* Graham David - $5.00
* Abbott Paul - $20.00
* Philip Tepfer - $10.00
* Eddy Marcus - $5.00
* Rockhold Keith - $50.00
* Sosa Diaz Ramon - $10.00
* Cordeiro Goncalo - $25.00
* Wspanialy Marzena - $10.00
* Pascual Nicolas - $10.00
* Ejaz Hassan - $10.00
* Hines Frank - $100.00
* Triana Vega Luis - $10.00
* PROMOTUX DI FRANCESCO MELONI E C. S.N.C. - $15.00
* Emmanuel Kielichowski - $15.00
* 우공이산​우공이산 - $50.00
* Empirica srl - $15.00
* Gareballa Hassan - $10.00
* Yi Jihwang - $10.00
* Kose Onur - $15.00
* Вейсов​Александр - $30.00
* Blinov Anton - $30.00
* Pulikonda Tharakesh - $10.00
* Linear Design Group, LLC - $20.00
* Feldman Alon - $100.00
* De Rosa Fabian - $5.00
* Wang Zhe - $35.00
* Schaefer Daniel - $10.00
* Burch Martin - $25.00
* Макогон​Виталий - $10.00
* avappstore - $2.50
* Burch Martin - $10.00
* Mazdrashki Kamen - $20.00
* Hilker Daniel - $3.00
* Grokability, Inc. - $100.00
* Zweimüller Boris - $10.00
* Chen Qiurong - $5.00
* Mirkarimov Dmitriy - $10.00
* Cruz Ambrocio Jose - $5.00
* Brinkmeier Dirk - $20.00
* Kennelly James - $100.00
* Barreiro Lionel - $25.00
* Toh Alvin - $10.00
* ERIKAUSKAS - $100.00
* Miqueles Pino Jonatan - $100.00
* Wacker Jonathan - $1.00

## 支付宝

* 萃华：10.18元
* 小马哥：5元
* 振：20元
* 懒虫：8.8元
* rainc：50元
* 印：10元
* 大个子：50元
* 拓海真一：100元
* IO芒果：7元
* 醉、千秋：18.88元
* 路人甲：5.27元
* 小阿吉：20元
* FastAdmin - F4NNIU：88.88元

## 微信

* 一牛九毛：100元
* 笑：50元
* 111111：4元
* 佚名：6.6元
* Evo4me：30元
* zhang：50.05元
* 郝亮：20元
* 王挺：6.6元
* 无心向你：9.9元
* 指间沙：9.9元
* 董琛：9.9元
* 朝阳：8元

注：由于支付宝和微信使用匿名的方式，导致无法查询捐助者，麻烦发送邮件告知捐助信息，谢谢。
