require('../../common/welcome')()
